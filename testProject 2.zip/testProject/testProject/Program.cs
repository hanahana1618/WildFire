﻿using System;

namespace testProject
{
	class MainClass
	{
		public static void Main(string[] args)
		{
			dbConnection.Init(); //database yayy
		}


	}
}
