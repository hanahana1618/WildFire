﻿<form action = "testForm.php" method= "post" />
<p>Input 1: <input type="text" name="input
