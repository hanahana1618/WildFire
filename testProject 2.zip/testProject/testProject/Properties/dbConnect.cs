﻿using System;
using MySql.Data;
using System.Data;
using MySql.Data.MySqlClient;

namespace testProject
{
	public static class dbConnection
	{
		public static void Init()
		{
			MySqlConnection conn;
			MySqlCommand command;
			string myConnectionString;

			myConnectionString = "server=159.203.166.65;uid=wildfire;" +
				"pwd=password;database=wildfire;";

			try
			{
				conn = new MySqlConnection();
				conn.ConnectionString = myConnectionString;
				conn.Open();

				command = conn.CreateCommand();
				command.CommandText = //"Authors;\n\nCREATE TABLE IF NOT EXISTS Authors(Id INT PRIMARY KEY AUTO_INCREMENT," +
				"INSERT INTO `test` (`name`, `location`) VALUES ('TESTING', 'TESTING');";
			

				command.ExecuteScalar();
			//	Console.WriteLine(version);

			}
			catch (MySqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
		}
	}
}